package Queue;

import java.util.*;

public class Q1 {
int front;
int rear;
int max=5;
int m;
int Q[]=new int[max];
Q1()
{
rear=0;
front=0;
}
boolean isEmpty()
{
	if(rear==front)
	{
		return true;
	}
	return false;
	
}

boolean isFull()
{
	if(rear==max)
	{
		return true;
	}
	return false;
}
void insert(int data)
{
if(isFull())
{
	System.out.println("Queue Full");
}
else {
	Q[rear]=data;
//	rear++;
	System.out.println(rear+"== p =="+Q[rear]);
	rear++;
}
	
	}


void delete()
{
	if(isEmpty())
	{
		System.out.println("Queue Empty");
	}
	else {
		System.out.println(front+"== p =="+Q[front]);
		Q[front]=m;
		front++;
	}

}

void peek()
{
	

}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Q1 q=new Q1();
Scanner sc=new Scanner(System.in);
String c1;
int n,data;
do {
	n=sc.nextInt();

	switch(n)
	{
	case 1:
		data=sc.nextInt();
		q.insert(data);
		break;
	case 2:
		q.delete();
		break;
	case 3:
		q.peek();
	break;
	}
	System.out.println("enter yes");
	sc.nextLine();
	c1=sc.nextLine();
}while(c1.equals("yes"));
		
	}

}
