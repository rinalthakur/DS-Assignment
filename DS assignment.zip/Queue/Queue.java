package Queue;

public class Queue {
	int front;
	int rear;
	public static final int max=5;
	int Q[]=new int[max];
	Queue()
	{
		front=-1;
		rear=-1;
	}
	
	boolean isEmpty()
	{
		if(front==rear)
		{
			return true;
		}
		return false;
		
		
	}
	
	boolean isFull()
	{
		if(rear>=max-1)
		{
			return true;
		}
		return false;
		
		
	}
	void insert(int a)
	{
	front=0;
		if(!isFull())
		{
		
			Q[++rear]=a;
			System.out.println(rear+"  ==== "+Q[rear]);
			
		}
		else {
		
			System.out.println("queue is full");
		}
		
	}
	
	void deleteQ(){
		if(isEmpty())
		{
			System.out.println("queue is Empty");
		}
		else {
			int m=Q[front++];
			System.out.println(front+" front ==== "+Q[front]);
		}
	}
	void peek()
	{
		System.out.println(rear+" :"+Q[rear]+"  \n "+front+" :"+Q[front]);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue q=new Queue();
		int a=10,b=20,c=30,d=40,e=50;
		q.insert(a);
		q.insert(b);
		q.insert(c);
		q.insert(d);
		q.insert(e);
		q.deleteQ();
		q.deleteQ();
		q.insert(d);
		q.peek();
	}

}
