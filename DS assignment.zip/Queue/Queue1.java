package Queue;

import java.util.*;

public class Queue1 {
	static int front;
	static int rear;
	public static final int max=5;
	int Q[]=new int[max];
	int m;
	Queue1()
	{
		front=0;
		rear=0;
	}
	
	boolean isEmpty()
	{
		
		if(front==rear)
		{
			System.out.println("rear =="+rear+"front"+front);
			return true;
		}
		else if(front==max && rear>=0) {
			front=0;
			return false;
		}
		
	return false;
		
		
	}
	boolean isFull()
	{
		if(rear==max&&front==0)
		{
			return true;
		}
		else if(front>0&& rear==max)
		{
			rear=0;
			return false;
		}

		return false;
		
	}
	void insert(int a)
	{
		if(isFull())
		{
			System.out.println("Queue is full and you are try to insert element");
		
		}
	 else 
		{
		 if(!isFull()&&Q[rear]==0)
			{
				
			Q[rear]=a;
			System.out.println("index :"+rear+"insert :"+Q[rear]);
			rear++;
			}
		 else {
			 System.out.println("Queue is full and you are try to insert element");
		 }
		}
		
		
		
	
	}
	void deleteQ()
	{
		if(isEmpty()&&Q[front]!=0)
		{
			
			System.out.println("Queue is Empty and you are try to delete element"+front);
			
		}
		else {
			if(!isEmpty())
			{
				 System.out.println("index :"+front+"deleted:"+Q[front]);
					Q[front]=m;
					 front++;
			
		}
			else {
				System.out.println("Queue is Empty");
			}	
		}
		
	}
	void peek()
	{
		
		System.out.println("Queue status ");
	
	for(int i=0;i<Q.length;i++)
	{
		
	//	if(Q[i]!=0)
	//	{
	//	System.out.println(" index :"+i+" element: "+Q[i]);
		//}
		//else {
			System.out.println(" index : "+i+" Queue "+Q[i]);
		//}
	}
	
			
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue1 q=new Queue1();
	/*	int a=10,b=20,c=30,d=40,e=50;
		q.insert(a);
	q.insert(b);
	q.insert(c);
	q.insert(d);
	q.insert(e);
	//q.deleteQ();
	//q.deleteQ();
		//q.deleteQ();
//q.insert(d);
//q.insert(6);
	q.deleteQ();
	q.deleteQ();
q.insert(16);
//q.deleteQ();
//q.deleteQ();
	//q.insert(10);
q.insert(20);
//q.deleteQ();
q.insert(2);
q.deleteQ();
q.deleteQ();
q.deleteQ();
q.insert(70);
q.insert(2);
//q.deleteQ();
//q.insert(30);
//q.deleteQ();
q.peek();*/
Scanner sc=new Scanner(System.in);
String c1;
int n,data;
do {
	n=sc.nextInt();

	switch(n)
	{
	case 1:
		data=sc.nextInt();
		q.insert(data);
		break;
	case 2:
		q.deleteQ();
		break;
	case 3:
		q.peek();
	break;
	}
	System.out.println("enter yes");
	sc.nextLine();
	c1=sc.nextLine();
}while(c1.equals("yes"));
		
	}

}
