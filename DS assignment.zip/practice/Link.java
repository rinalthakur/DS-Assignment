package practice;


	import java.util.Scanner;
	public class Link {
	void match(String str)
	{
		System.out.println(str);
		}
		public static void main(String args[])
		{
			Link l=new Link();
		Scanner sc=new Scanner(System.in);
				int n=sc.nextInt();
				sc.nextLine();
				String str;
				for(int i=0;i<n;i++)
				{
					str=sc.nextLine();
					l.match(str);
				}
				
		}
	}


