package practice;

public class Rotation {
	
	 static void rotated(int[] arr, int ele) {
		 int temp[]=new int[ele+1];
		 int arr1[]=new int[arr.length];
		 int j=0;
		 
		for(int i=0;i<arr.length;i++)
		{
			if(i<=ele){
				temp[i]=arr[i];
			}
			else {
				
				arr1[j]=arr[i];
				j++;
				
			}
			
		
			
			
		}
		int m=0;
	for(int i=0;i<arr.length;i++)
		{
	if(arr1[i]==0)
	{
			arr1[i]=temp[m];
			m++;
		}
	}
		
		for(int i:arr1)
		{
			System.out.println(i);
		}
		
		
	}
	
public static void main(String args[])
{
	int arr[]= {1,2,3,4};
	int ele=2;
	rotated(arr,ele);
}


	
}
