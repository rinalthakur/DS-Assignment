package Sorting;

public class BubbleSort {
	void sort(int []arr) {
		for (int i = 0; i <arr.length-1; i++) 
            for (int j = 0; j < arr.length-i-1; j++) 
                if (arr[j] > arr[j+1]) 
                { 
                    // swap arr[j+1] and arr[j] 
                    int temp = arr[j]; 
                    arr[j] = arr[j+1]; 
                    arr[j+1] = temp; 
                } 
			
		
		
		System.out.println("\n After sorting ");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BubbleSort b=new BubbleSort();
		int a[]= {11,9,8,7,6,4,5,3,2,10};
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		b.sort(a);
		
	}

}
