package DSEXAM;

public class SinglyLink {
static class Node{
	int data;
	Node next;
	Node(int data)
	{
		this.data=data;
		next=null;
	}
}
Node head;
Node second;

void insertBeg(int data)
{
	Node newele=new Node(data);
	newele.next=head;
	head=newele;

}

void insertBeg1(int data)
{
	Node newele=new Node(data);
	newele.next=second;
	second=newele;

}

Node concat(Node head,Node second)//concate
{
Node cur;
if(head==null)
	return second;
if(second==null)
	return head;
cur=head;
while(cur.next!=null)
{
cur=cur.next;	
}
cur.next=second;
return head;
}

void insertEnd(int data)
{
	if(head==null)
	{
		insertBeg(data);
		return;
	}
	Node cur=head;
	Node newele=new Node(data);
	while(cur.next!=null)
	{
		cur=cur.next;
	}
	cur.next=newele;
	
	
	}

void insertpos(int data,int pos)
{
	
	if(head==null)
	{
		insertBeg(data);
		return;
	}
	int count=0;
	Node cur=head;
	Node newele=new Node(data);
	while(cur!=null)
	{
		count++;
		if(count==pos) break;
		cur=cur.next;
	}
//	newele.next=pre.next;
	//pre.next=newele;
	newele.next=cur.next;
	cur.next=newele;
	
}
void display(Node head)
{
Node cur=head;
int countN=0;

while(cur!=null)
{
	countN++;
System.out.println(cur.data);
cur=cur.next;
}
System.out.println("NumberOf Nodes"+countN);
}

void deleteBeg()
{
	Node cur=head;
	head=cur.next;
}

void deleteEnd()
{
Node cur=head;
Node temp=cur;
while(cur.next!=null)
{
	temp=cur;
cur=cur.next;	
}
temp.next=null;
}

void deletepos(int pos)
{
	Node cur=head;
	Node temp=cur;
	int count=0;
	while(cur!=null)
	{
		count++;
		if(count==pos) break;
		temp=cur;
		cur=cur.next;
	}
	temp.next=temp.next.next;
}

void revers()// Revers Link list
{
Node pointer=head;
Node pre = null;
Node cur=null;

while(pointer!=null)
{
cur=pointer;
pointer=pointer.next;
cur.next=pre;
pre=cur;
head=cur;
}
}
	public static void main(String args[])
	{
		SinglyLink s=new SinglyLink();
		//s.insertBeg(30);
		//s.insertBeg(40);
		s.insertBeg(50);
		s.insertEnd(10);
		s.insertEnd(20);
		s.insertpos(30, 2);
		s.insertBeg1(100);
		s.insertBeg1(101);
		s.insertBeg1(102);
		s.insertBeg1(103);
		
	//	s.deleteBeg();
		//s.deleteBeg();
		s.insertpos(20, 1);
	//	s.deleteEnd();
		s.deletepos(2);
		s.display(s.head);
		System.out.println("concatenate\n");
		Node m=s.concat(s.head, s.second);
		s.display(m);
		System.out.println("revers\n");
		s.revers();
		
		s.display(s.head);
	}
}
