package DSEXAM;
import static java.lang.System.exit;
public class StackLinkList {
static class Node{
	int data;
	Node next;
	Node(int data)
	{
		this.data=data;
	}
	
}
Node Top;
StackLinkList()
{
	this.Top=null;
	}

public boolean isEmpty()
{
	return Top==null;
	}

public void push(int data)
{
	
	Node temp=new Node(data);
	if(temp==null)
	{
		System.out.println("heap overflow");
		return;
	}
	
	//temp.data=data;
	temp.next=Top;
	Top=temp;
	}

public  void pop()
{
if(Top==null)
{
	System.out.println("heap underflow");
}
Top=Top.next;
}






public void display() 
{ 
    if (Top == null) { 
        System.out.printf("\nStack Underflow"); 
       // exit(1); 
    } 
    else { 
        Node temp = Top; 
        while (temp != null) { 

           
            System.out.printf("%d->", temp.data); 

           
            temp = temp.next; 
        } 
    } 
} 
 








	public static void main(String[] args) {
		StackLinkList obj=new StackLinkList();
		 // insert Stack value 
        obj.push(11); 
        obj.push(22); 
        obj.push(33); 
        obj.push(44); 
  
        // print Stack elements 
        obj.display(); 
        obj.pop();
        System.out.println();
        obj.display(); 
	}

}
