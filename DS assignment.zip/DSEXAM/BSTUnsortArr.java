package DSEXAM;
import java.util.*;

public class BSTUnsortArr {
static class Node
{
	int data;
	Node left;
	Node right;
	Node(int data)
	{
		this.data=data;
		left=null;
		right=null;
		
	}
	}
static Node insert(Node root,int data)// insert node
{
	if(root==null)
		return new Node(data);
	
	Node cur;
	if(data<=root.data)
	{
		cur=insert(root.left,data);
		root.left=cur;
	}
	else {
		cur=insert(root.right,data);
		root.right=cur;
	}
	return root;
	}



static void postorder(Node root)//print node
{
	if(root==null)
	{
		System.out.print(" null ");
	}
	
	
	try {
		System.out.print(root.data+" ");
	postorder(root.left);
	postorder(root.right);
	
	}catch(Exception e)
	{}
	}

//3 2 1  null  null  null 5 4  null  null 6  null 7  null  null 

static int height(Node root)// height of tree
{
	if(root==null)
	return -1;
	
	int l=height(root.left);
	int r=height(root.right);
	int total=Math.max(l, r)+1;
	
	return total;
	
}


public static Node lca(Node root, int v1, int v2) {// lowes common accesstor
  	// Write your code here.
        if(root==null)
    return null;
if(root.data > v1 && root.data > v2)
{
    System.out.println(root.left.data+""+v1+" "+v2);
  return lca(root.left,v1,v2);
}
  
if(root.data < v1 && root.data < v2)
{
     System.out.println(root.right.data+"v1"+v1+""+v2);
    return lca(root.right,v1,v2);
}
   
    return root;
}

static int max(Node root)
{
	if(root.right!=null)
	{
		return max(root.right);
		
	}
	else {
		return root.data;
	}
	}

static Node Delete(Node root,int data)//delete node
{
	if(root==null)
		return null;
	
	if(data>root.data)
	{
		root.right=Delete(root.right,data);
	}
	else if(data<root.data)
	{
		root.left=Delete(root.left,data);
	}
	else {
		if(root.left!=null&&root.right!=null)
		{
			int lmax=max(root.left);
			root.data=lmax;
			root.left=Delete(root.left,lmax);
			return root;
			
			
			
		}
	else if(root.left!=null)
		{
			return root.left;
		}
		else if(root.right!=null)
		{
			return root.right;
		}
		else {
			return null;
		}
	}
	return root;
	
}




	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int t=sc.nextInt();
	Node root=null;
	while(t-- >0)
	{
		int data=sc.nextInt();
		root=insert(root,data);
		//t-- ;
	}
	sc.close();
	Delete(root,6);
	postorder(root);
	System.out.println("height "+height(root));
	Node ans=lca(root,6,7);
	System.out.println(ans.data);
	
	
	}

}
