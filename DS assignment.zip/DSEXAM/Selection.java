package DSEXAM;

public class Selection {
	
	void sort(int []arr) {
		int n=arr.length;
	for(int i=0;i<n-1;i++)//i=1
	{
		int mid=i;//4
		for(int j=i+1;j<n;j++)//\
		{
			if(arr[j]<arr[mid])
				mid=j;
		}
				
		int temp=arr[mid];
		arr[mid]=arr[i];
		arr[i]=temp;
		
	}
         
	System.out.println("\n After sorting ");
	for(int k=0;k<n;k++)
	{
		System.out.print(arr[k]+" ");
		
	}
           
		}
		
			
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Selection b=new Selection();
		int a[]= {11,9,9,7,6,4,5,3,2,10};
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		b.sort(a);
		
	}

}
