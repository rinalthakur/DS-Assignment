package DSEXAM;

public class BinnarySearchTree {
static class Node{
	int data;
	Node left;
	Node right;
	Node(int data,Node left,Node right)
	{
		this.data=data;
		this.left=left;
		this.right=right;
	}
}
Node Bst(int[] arr,int lo,int hi)
{
	if(lo>hi)
		return null;
	int mid=(lo+hi)/2;
	int data=arr[mid];
	Node left=Bst(arr,lo,mid-1);
	Node right=Bst(arr,mid+1,hi);
	Node node=new Node(data,left,right);
	
return node;	
}

void preorder(Node node)
{
	try {
	System.out.println(node.data);
	preorder(node.left);
	preorder(node.right);
	}
	catch(Exception e)
	{}
	}

	public static void main(String[] args) {
//int arr[]= {12,25,37,50,62,72,87};
	int arr[]= {2,4,8,6,7,3,9};
	BinnarySearchTree b=new BinnarySearchTree();
	Node node=b.Bst(arr,0,arr.length-1);
	b.preorder(node);

	}

}
