package DSEXAM;

public class CircularQueue {
int capacity=5;
int size=0;
int rear=-1;
int front=0;
int arr[]=null;
CircularQueue()
{
	this.arr=new int[capacity];
}

CircularQueue(int capacity)
{
	this.arr=new int[capacity];
}

void enqueue(int data)
{if(size==capacity)
{
	System.out.println("Queue is full");
return;	
}
	rear=(rear+1)%capacity;
	
	arr[rear]=data;
	size++;
	System.out.println(data+"enterd");
	System.out.println(rear+"after enqueue raer");
	
	
}

void dequeue()
{
	if(size==0)
	{
		System.out.print("Que is empty");
		return;
	}
int data=arr[front];
front=(front+1)%capacity;
size--;
System.out.println(data+"Delete");
System.out.println(front+"after enqueue front");


}



int size()
{
return size;}
	public static void main(String[] args) {
		CircularQueue c=new CircularQueue();
		c.enqueue(10);
		c.enqueue(20);
		c.enqueue(30);
		c.enqueue(40);
		c.enqueue(50);
		c.dequeue();
		c.enqueue(60);

	}

}
