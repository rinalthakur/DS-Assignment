package Stack;

public class GenStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	//	GenericStack<Character> p=new GenericStack<Character>();
		Integer a=10,b=20,c=5,d=6;
		
		//p.push(a);
		//p.pop();
		//p.push(b);
		//p.push(c);
		//p.push(d);
		//p.pop();
		//p.pop();
		//p.peek();

	}

}
