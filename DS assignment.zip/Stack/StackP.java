package Stack;

public class StackP {
	public static final int max=5;
	int a[]=new int[max];
	int Top;
	StackP()
	{
		Top=-1;
	}
	boolean isEmpty()
	{
		if(Top<0)
		{
			
		return true;
		}
		return false;
		
	}
	boolean isFull()
	{
		if(Top>=(max-1))
		{

			return true;
		}
		return false;
	}
	
	void push(int ab)
	{
		if(isFull())
		{
			System.out.println("Stack is overflow");
			
		}
		else {
				
				a[++Top]=ab;
		}
		
	}
	
	void pop()
	{
		if(isEmpty())
		{
		 
		  System.out.println("Stack is underflow(empty)");
		}
		else { int m=0;
		a[Top--]=m;
			
		}
	}
	
	void peek()
	{
		if(isEmpty())
		{
			System.out.println("stack is Underflow");
		}
		else {
		System.out.print("top value "+Top+" "+a[Top]);
		}
		
		for(int i:a)
		{
			System.out.println("\n"+i);
		}
		
	}
	
	

}
