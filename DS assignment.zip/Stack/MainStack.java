package Stack;

public class MainStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			StackP p=new StackP();
			int a=10,b=20,c=5,d=6;
			
			p.push(a);
			//p.pop();
			p.push(b);
			p.push(c);
			p.push(a);
			p.push(d);
			p.pop();
			//p.pop();
			p.peek();

			}
	

}
