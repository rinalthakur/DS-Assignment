package Stack;
import java.util.*;
public class Paranthisis {
	GenericStack s=new GenericStack();
	Scanner sc=new Scanner(System.in);
String str;
void setInput()
{
	int countOp=0;
	int countCp=0;
	str=sc.nextLine();
	char ch[]=str.toCharArray();
	for(int i=0;i<ch.length;i++)
	{
		if(ch[i]=='(')
		{
			s.push(ch[i]);
			countOp++;
			
		}
		if(!s.isEmpty()) {
	    if(ch[i]==')')
		{
			s.pop();
			countCp++;
		}
		}
		
	}
	
	 
	if(countOp==countCp) {
		System.out.println("Balance");
	}
	else {
		System.out.println("Not Balance");
	}
}
	public static void main(String[] args) {
		Paranthisis p=new Paranthisis();
		p.setInput();

	}

}
