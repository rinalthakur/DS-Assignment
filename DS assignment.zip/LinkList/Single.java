package LinkList;
class Node{
	
	int data;
	Node next;
	public Node(int i) {
		data=i;
	}
}
public class Single {
Node head;
void display()
{
	Node n = head; 
    while (n != null) { 
        System.out.print(n.data + " "); 
        n = n.next; 
    } 
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Single s=new Single();
s.head=new Node(10);
Node n1=new Node(20);
Node n2=new Node(30);
Node n3=new Node(40);
s.head.next=n1;
n1.next=n2;
n2.next=n3;
s.display();

	}

}
