package LinkList;
import java.util.*;
public class SingleLinkList {
Node head;
static class Node{
	
	int data;
	Node next;
	public Node(int i) {
		data=i;
		next=null;
	}
}
public void create(int a)
{
	
	Node newNode=new Node(a);
	newNode.next=head;
	 head=newNode;

	
	
	}


void createAtEnd(int a)
{
	
	Node current;
	Node newNode=new Node(a);

	current=head;
	while(null!=current.next)
	{
		current=current.next;
	}
	current.next=newNode;
	
	}

void MidleInsert(Node pre,int data)
{
	if (pre == null)  
    {  
        System.out.println("The given previous node cannot be null");  
        return;  
    }  
	Node newele=new Node(data);
	newele.next=pre.next;
	pre.next=newele;

}
void display()
{
	Node n = head; 
    while (n != null) { 
        System.out.print(n.data + " "); 
        n = n.next; 
    } 
}

void deleteBeg()
{
	
	Node temp;
	if(head==null)
	{
		System.out.println("Link lis Empty you have to delete");
	}
	else {
	temp=head;
	head=head.next;
	temp.next=null;
	}
	
}
void deleteAtEnd()
{
	Node current=head;
	Node pre=null;
	while(current.next!=null)
	{
		pre=current;
		current=current.next;
	}
	pre.next=null;
	
}

void deleteAtPosition(int position)
{
	Node pre=head;
	int count=1;
	while(count<position-1)
	{
		pre=pre.next;
		count++;
	}
	Node current=pre.next;
	pre.next=current.next;
	//current=null;
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n;
		String str;
		SingleLinkList s=new SingleLinkList();
	//	s.deleteBeg();
		s.create(10);
		s.create(15);
		s.create(20);
		s.create(50);
		s.create(60);
//	s.createAtEnd(30);
//		s.createAtEnd(40);
		
		s.MidleInsert(s.head.next,40);
	
		//s.deleteBeg();
		//s.deleteAtEnd();
		s.deleteAtPosition(3);
		s.display();

	}

}
