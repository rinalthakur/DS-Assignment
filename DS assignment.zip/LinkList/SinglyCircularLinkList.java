package LinkList;

public class SinglyCircularLinkList {
	private Nodec head;
	private int length;
	static class Nodec
	{
		int data;
		Nodec fnext;
		
		Nodec()
		{
			this.data=data;
		}
		
	}
	SinglyCircularLinkList()
	{
		Nodec fnext=null;
		length=0;
	}
	
	public Nodec addToEmpty(Nodec last,int data)
	{
		if(last!=null)
		{
			return last;
		}
		
		Nodec newele=new Nodec();
		newele.data=data;
		last=newele;
		last.fnext=last;
		return last;
	}
	
	public Nodec addBegin(Nodec last,int data)
	{
		if(last==null)
		{
			return addToEmpty(last,data);
		}
		Nodec newele=new Nodec();
		newele.data=data;
		newele.fnext=last.fnext;
		last.fnext=newele;
		last=newele;
		
		return last;
	}
	
	 
	static void traverse(Nodec last)
	{
	    Nodec p;
	 
	    // If list is empty, return.
	    if (last == null)
	    {
	        System.out.println("List is empty.");
	        return;
	    }
	 
	    // Pointing to first Node of the list.
	    p = last.fnext;
	 
	    // Traversing the list.
	    do
	    {
	        System.out.print(p.data + " ");
	        p = p.fnext;
	 
	    }
	    while(p != last.fnext);
	 
	}
	public static void main(String[] args) {
		Nodec last=null;
		SinglyCircularLinkList cs=new SinglyCircularLinkList();
		last=cs.addToEmpty(last, 30);
		last=cs.addBegin(last, 10);
		last=cs.addBegin(last, 20);
		cs.traverse(last);

	}

}
