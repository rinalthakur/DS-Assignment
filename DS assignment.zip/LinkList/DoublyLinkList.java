package LinkList;
import java.util.*;
public class DoublyLinkList {
	private NodeD head;
private int length;
	static class NodeD
	{
	int data;
	NodeD fNext;
	NodeD bNext;
	NodeD(int data)
	{
		this.data=data;
		NodeD fNode,bNode=null;
	}
	}
	DoublyLinkList()
	{
		this.head=null;
		int length=0;
		
	}
	
	void insertAtBegning(int data)//insert at Beginning
	{
	
		NodeD newele=new NodeD(data);
		if(head==null)
		{
			head=newele;
		}
		else {
			
		head.bNext=newele;
		newele.fNext=head;
		head=newele;
		
		
		}
		length++;
		
		
		}
	
	void insertEnd(int data)// insert at End
	{
		NodeD newele=new NodeD(data);
	if(head==null)
	{
	head=newele;	
	}
	else {
		NodeD pre=head;
		while(pre.fNext!=null)
		{
			pre=pre.fNext;
		}
		pre.fNext=newele;
		newele.bNext=pre;
	}
		length++;
	}
	void printData()
	{
		NodeD current=head;
		while(current.fNext!=null)
		{
			System.out.print(current.data+"-> ");
			current=current.fNext;
		}
		System.out.println(current.data);
	}
	
	void insertAtPosition(int data,int pos)/// insert at position
	{
		if(pos==1)
		{
			insertAtBegning(data);
		}
		else if(pos>length)
		{
			insertEnd(data);
		}
		else {
			NodeD pre=head;
			NodeD newele=new NodeD(data);
			int i=1;
			while(pre.fNext!=null)
			{
				i++;
				
				if(i==pos) break;
				pre=pre.fNext;
				
				
			}
			newele.bNext=pre;
			newele.fNext=pre.fNext;
			pre.fNext.bNext=newele;
			pre.fNext=newele;
			
			
			length++;
		}
	
	}
	
	void deletBignning()
	{
		NodeD pre=head;
	
		if(head==null)
		{
			System.out.println("list is empty");
			
		}
		else {
			try {
				head=pre.fNext;
				head.bNext=null;
				
					}
					catch(Exception e)
					{
						
					}
		System.out.println("delete at Begnning"+pre.data);
		length--;
		}
	
		
	}
	

	void deleteAtEnd()
	{
		NodeD pre=head;
		if(head==null)
		{
			
			System.out.println("Empty link list");
		}else if(pre.fNext==null)
		{
			deletBignning();
		}
		else {
			
			try
			{
			while(pre.fNext.fNext!=null)
			{
				pre=pre.fNext;
			}
			System.out.println("delete at End"+pre.fNext.data);
			pre.fNext.bNext=null;
			
			pre.fNext=null;
			
			}
			catch(Exception e)
			{
				
			}
			
			length--;
			
		}
		
		
	}
	
	void deleteAtPosition(int pos)
	{
		if(pos<0)
		{
			System.out.println("pos can not be zero or less than zero");
		}
		else if(pos==1)
		{
			deletBignning();
		}
		else if(pos==length)
		{
			deleteAtEnd();
		}
		else {
			try
			{
			NodeD pre=head;
			int i=1;
			while(pre.fNext!=null)
			{
				i++;
				if(i==pos) break;
				pre=pre.fNext;
			}
			System.out.println(pre.fNext.data);
			pre.fNext.fNext.bNext=pre;
			pre.fNext=pre.fNext.fNext;
			} catch(Exception e)
			{}
			length--;
		}
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DoublyLinkList b=new DoublyLinkList();
		Scanner sc=new Scanner(System.in);
		int n;
		int data;
		int pos;
		String str;

		do {
			
			System.out.println("Enter 1)Insert at Begnning \n 2)Insert at position \n3)Insert at End \n4)Display\n 5)delete at Begnning \n 6) delete at End");
			n=sc.nextInt();
			switch(n)
			{
			case 1:
				System.out.println("enter data ");
				sc.nextLine();
			data=sc.nextInt();
				b.insertAtBegning(data);
			
				break;
			case 2:
				//sc.nextLine();
				System.out.println("enter data and position");
				data=sc.nextInt();
				pos=sc.nextInt();
			
				b.insertAtPosition(data, pos);
				
				break;
			case 3:
				System.out.println("enter data ");
				data=sc.nextInt();
				b.insertEnd(data);
	
				break;
			
			case 4:
				System.out.println("display data ");
				b.printData();
	
				break;
            case 5:
				
				b.deletBignning();
				
				break;
            case 6:
            	b.deleteAtEnd();
            	break;
            case 7:
            	System.out.println("Enter position");
            	pos=sc.nextInt();
            	b.deleteAtPosition(pos);
            	break;
				default:
					System.out.println("something");
			
			}
			sc.nextLine();
			System.out.println("Enter yes for continue");
			str=sc.nextLine();
			
			
		}while(str.equals("yes"));
		
		
	
		
		
	}

}
